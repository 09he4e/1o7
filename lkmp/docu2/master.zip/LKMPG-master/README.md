# The Linux Kernel Module Programming Guide

This is a project to keep the kernel module programmer's guide reasonably up to date, with working examples for recent kernel versions. The guide has been around since 2001 and most copies of it on the web only describe old 2.6.x kernels.

The text is in Emacs org-mode format with embedded C code examples, also exported in html format for convenient viewing.

The original guide may be found at http://www.tldp.org/LDP/lkmpg/
